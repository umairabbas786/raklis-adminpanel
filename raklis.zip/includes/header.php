<?php 
ob_start();
session_start();
include "includes/conn.php";
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demos.creative-tim.com/material-dashboard-bs4/examples/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 Jun 2022 17:59:35 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>
    Dashboard | Raklis
  </title>
<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
<link rel="stylesheet" href="maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">

<link href="assets/css/material-dashboard.min1c51.css?v=2.1.2" rel="stylesheet" />

<link href="assets/demo/demo.css" rel="stylesheet" />
</head>
<body class="">